#pragma once

void MenuPrincipal();
void MenuAlumno();
void MenuExamen();
