#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

void error_msj(const char *msj, int x = -1, int y = -1);
void ok_msj(const char *msj, int x = -1, int y = -1);

#endif // FUNCIONES_H_INCLUDED
