#include <iostream>
using namespace std;
#include "menu.h"
#include <clocale>
#include "sesion.h"

Alumno  g_alu; /// Acá definen la variable global con el usuario logueado.

int main(){

    g_alu.setApellidos("Simon");
    g_alu.setNombres("Global");
    g_alu.setLegajo(1);
    g_alu.setIDCarrera(1);

    setlocale(LC_ALL, "Spanish");
    MenuPrincipal();
    return 0;
}
