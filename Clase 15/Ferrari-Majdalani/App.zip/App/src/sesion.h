#ifndef SESION_H_INCLUDED
#define SESION_H_INCLUDED

#include "alumno.h"
extern Alumno g_alu; /// Acá declaran la variable global con el usuario logueado.

#endif // SESION_H_INCLUDED
